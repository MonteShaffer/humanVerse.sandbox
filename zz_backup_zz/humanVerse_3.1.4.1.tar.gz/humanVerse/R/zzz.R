
.onLoad = function(libname, pkgname)
  {
  initMemory();
  invisible();
  }


.onUnload = function(libname, pkgname)
  {
  invisible();
  }


